DSCH 3.5
VERSION 5/19/2026 3:12:08 PM
BB(46,-20,140,65)
SYM  #button
BB(46,31,55,39)
TITLE 50 35  #B
MODEL 59
PROP                                                                                                                                    
REC(47,32,6,6,r)
VIS 1
PIN(55,35,0.000,0.000)B
LIG(54,35,55,35)
LIG(46,39,46,31)
LIG(54,39,46,39)
LIG(54,31,54,39)
LIG(46,31,54,31)
LIG(47,38,47,32)
LIG(53,38,47,38)
LIG(53,32,53,38)
LIG(47,32,53,32)
FSYM
SYM  #pmos
BB(75,10,95,30)
TITLE 90 15  #pmos
MODEL 902
PROP   0.5u 0.05u MP                                                                                                                               
REC(76,15,19,15,r)
VIS 0
PIN(95,10,0.000,0.000)s
PIN(75,20,0.000,0.000)g
PIN(95,30,0.003,0.003)d
LIG(75,20,81,20)
LIG(83,20,83,20)
LIG(85,26,85,14)
LIG(87,26,87,14)
LIG(95,14,87,14)
LIG(95,10,95,14)
LIG(95,26,87,26)
LIG(95,30,95,26)
VLG pmos pmos(drain,source,gate);
FSYM
SYM  #nmos
BB(55,35,75,55)
TITLE 70 40  #nmos
MODEL 901
PROP   0.3u 0.05u MN                                                                                                                               
REC(56,40,19,15,r)
VIS 0
PIN(75,55,0.000,0.000)s
PIN(55,45,0.000,0.000)g
PIN(75,35,0.003,0.003)d
LIG(65,45,55,45)
LIG(65,51,65,39)
LIG(67,51,67,39)
LIG(75,39,67,39)
LIG(75,35,75,39)
LIG(75,51,67,51)
LIG(75,55,75,51)
VLG nmos nmos(drain,source,gate);
FSYM
SYM  #button
BB(131,21,140,29)
TITLE 135 25  #A
MODEL 59
PROP                                                                                                                                    
REC(132,22,6,6,r)
VIS 1
PIN(140,25,0.000,0.000)A
LIG(139,25,140,25)
LIG(131,29,131,21)
LIG(139,29,131,29)
LIG(139,21,139,29)
LIG(131,21,139,21)
LIG(132,28,132,22)
LIG(138,28,132,28)
LIG(138,22,138,28)
LIG(132,22,138,22)
FSYM
SYM  #vdd
BB(90,-20,100,-10)
TITLE 93 -14  #vdd
MODEL 1
PROP                                                                                                                                    
REC(0,0,0,0, )
VIS 0
PIN(95,-10,0.000,0.000)vdd
LIG(95,-10,95,-15)
LIG(95,-15,90,-15)
LIG(90,-15,95,-20)
LIG(95,-20,100,-15)
LIG(100,-15,95,-15)
FSYM
SYM  #vss
BB(90,57,100,65)
TITLE 94 62  #vss
MODEL 0
PROP                                                                                                                                    
REC(90,55,0,0,b)
VIS 0
PIN(95,55,0.000,0.000)vss
LIG(95,55,95,60)
LIG(90,60,100,60)
LIG(90,63,92,60)
LIG(92,63,94,60)
LIG(94,63,96,60)
LIG(96,63,98,60)
FSYM
SYM  #pmos
BB(95,-10,115,10)
TITLE 100 -5  #pmos
MODEL 902
PROP   0.5u 0.05u MP                                                                                                                               
REC(95,-5,19,15,r)
VIS 0
PIN(95,-10,0.000,0.000)s
PIN(115,0,0.000,0.000)g
PIN(95,10,0.003,0.002)d
LIG(115,0,109,0)
LIG(107,0,107,0)
LIG(105,6,105,-6)
LIG(103,6,103,-6)
LIG(95,-6,103,-6)
LIG(95,-10,95,-6)
LIG(95,6,103,6)
LIG(95,10,95,6)
VLG pmos pmos(drain,source,gate);
FSYM
SYM  #nmos
BB(120,35,140,55)
TITLE 125 40  #nmos
MODEL 901
PROP   0.3u 0.05u MN                                                                                                                               
REC(120,40,19,15,r)
VIS 0
PIN(120,55,0.000,0.000)s
PIN(140,45,0.000,0.000)g
PIN(120,35,0.003,0.003)d
LIG(130,45,140,45)
LIG(130,51,130,39)
LIG(128,51,128,39)
LIG(120,39,128,39)
LIG(120,35,120,39)
LIG(120,51,128,51)
LIG(120,55,120,51)
VLG nmos nmos(drain,source,gate);
FSYM
CNC(95 35)
LIG(95,30,100,30)
LIG(55,20,55,45)
LIG(75,20,55,20)
LIG(140,0,140,45)
LIG(115,0,140,0)
LIG(120,55,75,55)
LIG(95,35,120,35)
LIG(95,35,75,35)
LIG(95,30,95,35)
TEXT 98 28  #OUT
FFIG C:\Users\acer\Desktop\S42\IC\IC HW\1210159_NOR2.sch
