DSCH 3.5
VERSION 5/19/2026 3:08:49 PM
BB(41,-5,139,85)
SYM  #button
BB(130,36,139,44)
TITLE 135 40  #B
MODEL 59
PROP                                                                                                                                    
REC(132,37,6,6,r)
VIS 1
PIN(130,40,0.000,0.000)B
LIG(131,40,130,40)
LIG(139,44,139,36)
LIG(131,44,139,44)
LIG(131,36,131,44)
LIG(139,36,131,36)
LIG(138,43,138,37)
LIG(132,43,138,43)
LIG(132,37,132,43)
LIG(138,37,132,37)
FSYM
SYM  #button
BB(41,31,50,39)
TITLE 45 35  #A
MODEL 59
PROP                                                                                                                                    
REC(42,32,6,6,r)
VIS 1
PIN(50,35,0.000,0.000)A
LIG(49,35,50,35)
LIG(41,39,41,31)
LIG(49,39,41,39)
LIG(49,31,49,39)
LIG(41,31,49,31)
LIG(42,38,42,32)
LIG(48,38,42,38)
LIG(48,32,48,38)
LIG(42,32,48,32)
FSYM
SYM  #nmos
BB(85,55,105,75)
TITLE 90 60  #nmos
MODEL 901
PROP   0.3u 0.05u MN                                                                                                                               
REC(85,60,19,15,r)
VIS 0
PIN(85,75,0.000,0.000)s
PIN(105,65,0.000,0.000)g
PIN(85,55,0.003,0.002)d
LIG(95,65,105,65)
LIG(95,71,95,59)
LIG(93,71,93,59)
LIG(85,59,93,59)
LIG(85,55,85,59)
LIG(85,71,93,71)
LIG(85,75,85,71)
VLG nmos nmos(drain,source,gate);
FSYM
SYM  #pmos
BB(110,5,130,25)
TITLE 115 10  #pmos
MODEL 902
PROP   0.5u 0.05u MP                                                                                                                               
REC(110,10,19,15,r)
VIS 0
PIN(110,5,0.000,0.000)s
PIN(130,15,0.000,0.000)g
PIN(110,25,0.003,0.003)d
LIG(130,15,124,15)
LIG(122,15,122,15)
LIG(120,21,120,9)
LIG(118,21,118,9)
LIG(110,9,118,9)
LIG(110,5,110,9)
LIG(110,21,118,21)
LIG(110,25,110,21)
VLG pmos pmos(drain,source,gate);
FSYM
SYM  #vdd
BB(85,-5,95,5)
TITLE 88 1  #vdd
MODEL 1
PROP                                                                                                                                    
REC(0,0,0,0, )
VIS 0
PIN(90,5,0.000,0.000)vdd
LIG(90,5,90,0)
LIG(90,0,85,0)
LIG(85,0,90,-5)
LIG(90,-5,95,0)
LIG(95,0,90,0)
FSYM
SYM  #nmos
BB(65,35,85,55)
TITLE 80 40  #nmos
MODEL 901
PROP   0.3u 0.05u MN                                                                                                                               
REC(66,40,19,15,r)
VIS 0
PIN(85,55,0.000,0.000)s
PIN(65,45,0.000,0.000)g
PIN(85,35,0.003,0.003)d
LIG(75,45,65,45)
LIG(75,51,75,39)
LIG(77,51,77,39)
LIG(85,39,77,39)
LIG(85,35,85,39)
LIG(85,51,77,51)
LIG(85,55,85,51)
VLG nmos nmos(drain,source,gate);
FSYM
SYM  #pmos
BB(50,5,70,25)
TITLE 65 10  #pmos
MODEL 902
PROP   0.5u 0.05u MP                                                                                                                               
REC(51,10,19,15,r)
VIS 0
PIN(70,5,0.000,0.000)s
PIN(50,15,0.000,0.000)g
PIN(70,25,0.003,0.003)d
LIG(50,15,56,15)
LIG(58,15,58,15)
LIG(60,21,60,9)
LIG(62,21,62,9)
LIG(70,9,62,9)
LIG(70,5,70,9)
LIG(70,21,62,21)
LIG(70,25,70,21)
VLG pmos pmos(drain,source,gate);
FSYM
SYM  #vss
BB(80,77,90,85)
TITLE 84 82  #vss
MODEL 0
PROP                                                                                                                                    
REC(80,75,0,0,b)
VIS 0
PIN(85,75,0.000,0.000)vss
LIG(85,75,85,80)
LIG(80,80,90,80)
LIG(80,83,82,80)
LIG(82,83,84,80)
LIG(84,83,86,80)
LIG(86,83,88,80)
FSYM
CNC(85 25)
CNC(85 30)
LIG(70,5,110,5)
LIG(85,30,85,35)
LIG(85,25,85,30)
LIG(70,25,85,25)
LIG(85,25,110,25)
LIG(130,15,130,65)
LIG(85,30,90,30)
LIG(105,65,130,65)
LIG(50,45,65,45)
LIG(50,15,50,45)
TEXT 88 30  #OUT
FFIG C:\Users\acer\Desktop\S42\IC\IC HW\1210159_NAND2.sch
