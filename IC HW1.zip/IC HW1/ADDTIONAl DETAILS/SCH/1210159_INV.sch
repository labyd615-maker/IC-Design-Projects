DSCH 3.5
VERSION 5/19/2026 3:08:24 PM
BB(66,-5,137,60)
SYM  #pmos
BB(75,5,95,25)
TITLE 90 10  #pmos_1
MODEL 902
PROP   0.5u 0.05u MP                                                                                                                               
REC(76,10,19,15,r)
VIS 0
PIN(95,5,0.000,0.000)s
PIN(75,15,0.000,0.000)g
PIN(95,25,0.003,0.002)d
LIG(75,15,81,15)
LIG(83,15,83,15)
LIG(85,21,85,9)
LIG(87,21,87,9)
LIG(95,9,87,9)
LIG(95,5,95,9)
LIG(95,21,87,21)
LIG(95,25,95,21)
VLG pmos pmos(drain,source,gate);
FSYM
SYM  #nmos
BB(75,30,95,50)
TITLE 90 35  #nmos_2
MODEL 901
PROP   0.3u 0.05u MN                                                                                                                               
REC(76,35,19,15,r)
VIS 0
PIN(95,50,0.000,0.000)s
PIN(75,40,0.000,0.000)g
PIN(95,30,0.003,0.002)d
LIG(85,40,75,40)
LIG(85,46,85,34)
LIG(87,46,87,34)
LIG(95,34,87,34)
LIG(95,30,95,34)
LIG(95,46,87,46)
LIG(95,50,95,46)
VLG nmos nmos(drain,source,gate);
FSYM
SYM  #vss
BB(90,52,100,60)
TITLE 94 57  #gnd
MODEL 0
PROP                                                                                                                                    
REC(90,50,0,0,b)
VIS 0
PIN(95,50,0.000,0.000)vss
LIG(95,50,95,55)
LIG(90,55,100,55)
LIG(90,58,92,55)
LIG(92,58,94,55)
LIG(94,58,96,55)
LIG(96,58,98,55)
FSYM
SYM  #vdd
BB(90,-5,100,5)
TITLE 93 1  #vdd
MODEL 1
PROP                                                                                                                                    
REC(0,0,0,0, )
VIS 0
PIN(95,5,0.000,0.000)vdd
LIG(95,5,95,0)
LIG(95,0,90,0)
LIG(90,0,95,-5)
LIG(95,-5,100,0)
LIG(100,0,95,0)
FSYM
SYM  #button
BB(66,26,75,34)
TITLE 70 30  #IN
MODEL 59
PROP                                                                                                                                    
REC(67,27,6,6,r)
VIS 1
PIN(75,30,0.000,0.000)IN
LIG(74,30,75,30)
LIG(66,34,66,26)
LIG(74,34,66,34)
LIG(74,26,74,34)
LIG(66,26,74,26)
LIG(67,33,67,27)
LIG(73,33,67,33)
LIG(73,27,73,33)
LIG(67,27,73,27)
FSYM
LIG(75,15,75,40)
LIG(95,25,95,30)
LIG(95,25,100,25)
TEXT 97 25  #OUT
FFIG C:\Users\acer\Desktop\S42\IC\IC HW\1210159_INV.sch
